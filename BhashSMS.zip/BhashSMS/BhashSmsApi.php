<?php
//////////////////////////////////
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 'On');
ini_set("memory_limit","512M");
set_time_limit(0);
//////////////////////////////////

class BhashSmsApi
{
	function __construct()
	{
		include 'database.php';
		$this->con 			= $con;
		$this->con_working 	= $con_working;
		$this->stop 		= "stop";
		$this->api_id		= "API11082942526";
		$this->api_password	=	"123456789";
		$this->SenderID	=	"PRHCPL";
		$this->SmsType	=	"T";
		//1= Pune Clinic Shifting, 2= New Aundh Branch 
		$this->CampaignName	=	2;
		$this->SentDateTime	=	date("Y-m-d H:i:s");
		$this->MaxLoop	=	5000;
	}

	function getDataFromFiles()
	{
		$SrcFile	= 	"Registration File-new2.csv";

	    $handle = fopen($SrcFile, "r");

	    while(($data = fgetcsv($handle, 1000, ",")) !== FALSE)
	    {
	    	$NumbersWithoutDash	=	$data[7];

	    	$NumbersWithoutDash	=	$this->mobileNumberFilter($NumbersWithoutDash);

	    	if($NumbersWithoutDash == $this->stop){
	    		continue;
	    	}
	    	
	    	$Email 		=	$data[8];

	    	$NameSplit	=	explode(" ", $data[3]);

	    	$NameSplit 	= 	array_values(array_filter($NameSplit));

	    	$NameSplit	=	array_map('strtolower', $NameSplit);

	    	if(!in_array($NameSplit[0],array("mr","mr.","ms","ms.","mrs","mrs.","dr","dr.","master","master.","miss","miss."))){

	    		$FirstName 	= 	trim($NameSplit[0]);
	    		if(stripos($FirstName,"mr.") !== FALSE || stripos($FirstName,"ms.") !== FALSE || stripos($FirstName,"mrs.") !== FALSE || stripos($FirstName,"miss.") !== FALSE || stripos($FirstName,"mast.") !== FALSE){
	    			$DotSplit	=	explode(".",$FirstName);
	    			$DotSplit = array_values(array_filter($DotSplit));
	    			$FirstName	=	$DotSplit[1];
	    		}	
	    	}else{
	    		$FirstName	=	$NameSplit[1];
	    	}

	    	$FirstName	=	ucfirst($FirstName);

	    	$query = "INSERT INTO PsoriatreatSMSRecords (Number,PatientName,MessageSent,Email)VALUES('$NumbersWithoutDash','$data[3]','$FirstName','$Email')";

	    	if(!$this->con_working->query($query)){
				$this->messageOut(mysqli_error($this->con_working));
			}
	    }	
	}

	function getDataFromDB()
	{
		$GetQuery = "SELECT * FROM patientregistration";

	    $Patients = $this->con->query($GetQuery);

	    while($PatientData = mysqli_fetch_assoc($Patients))
	    {
	    	$mobileno 	= 	$PatientData['ContactNumber'];

	    	$mobileno	=	$this->mobileNumberFilter($mobileno);

	    	if($mobileno == $this->stop){
	    		continue;
	    	}
	    	
	    	$FullName = $PatientData['FirstName']." ".$PatientData['MiddleName']." ".$PatientData['LastName'];

	    	$FullName = addslashes($FullName);

	    	$FirstName 	= 	$PatientData['FirstName'];

	    	$Email 		=	$PatientData['Email'];

	    	$query = "INSERT INTO PsoriatreatSMSRecords (Number,PatientName,MessageSent,Email)VALUES('$mobileno','$FullName','$FirstName','$Email')";

	    	if(!$this->con_working->query($query)){
				$this->messageOut(mysqli_error($this->con_working));
	    	}
	    }
	}

	function sendSMS($Number="",$FirstName="",$Name="")
	{
		if($Number == "" && $FirstName == "" && $Name == ""){

			$GetRecords	=	"SELECT * FROM PsoriatreatSMSRecords ORDER BY id DESC LIMIT 2";

			$Records 	=	$this->con_working->query($GetRecords);

			while ($data = mysqli_fetch_assoc($Records)) {

				$MoNumber	=	$data['Number'];

				$FirstName	=	$data['MessageSent'];

				if(strlen($FirstName) > 10 || strlen($FirstName) < 3){
					$FirstName	=	"Patient";
				}
				
				$Message	=	$this->getMessageByCampaign($this->CampaignName,$FirstName);
				// $this->messageOut($Message);exit;
				$url		=	$this->buildSmsApiURL($MoNumber,$Message);

				$ResData	=	$this->makeCallAndResponseSMS($url);
				
				$this->getResponseAndAddLogs($ResData,$data['PatientName'],$FirstName,$MoNumber,$Message);
			}
		}
		else{
			if(strlen($FirstName) > 10 || strlen($FirstName) < 3){
				$FirstName	=	"Patient";
			}

			$Message	=	$this->getMessageByCampaign($this->CampaignName,$FirstName);

			$url		=	$this->buildSmsApiURL($Number,$Message);

			$ResData	=	$this->makeCallAndResponseSMS($url);
			
			$this->getResponseAndAddLogs($ResData,$Name,$FirstName,$Number,$Message);
		}   
	}

	function sendEmails()
    {
    	require 'PHPMailer/PHPMailerAutoload.php';

    	$mail = new PHPMailer;

    	$from 	=	"dr.sonawane@psoriatreat.net";

	    $mail->isSMTP();     
	    $mail->SMTPDebug = 0;                       
	    $mail->Host = 'mail.domsit.com'; 
	   
	    $mail->Username = 'nikhil.bhole@domsit.com';                 
	    $mail->Password = 'nikhilmae';
	 
	    $mail->SMTPAuth = true;
		$mail->SMTPSecure = 'ssl'; 
		$mail->Port = 465;                                   
	    $mail->setFrom($from, 'Psoriatreat Hospital and Research Center');
	    $mail->isHTML(true);                                 
	    
	    $mail->Subject = "Clinic Shifting Address";

		//$Query 		=	"SELECT * FROM PsoriatreatSMSRecords WHERE `Email` != '' ORDER BY id DESC LIMIT 4";
		$Query = "SELECT DISTINCT `MessageSent`, `Email` FROM `PsoriatreatSMSRecords` WHERE `Email` != '' ORDER by `MessageSent` ASC";
		//$Query =  "SELECT * FROM temp_emails WHERE `Email` != '' ORDER BY id DESC LIMIT 3";
    	$Records 	=	$this->con_working->query($Query);

		$SendCount	= 	0;
		$TotalRecordCount	= 	0;
		$InvalidRecordCount	= 	0;

    	while ($data = mysqli_fetch_assoc($Records))
    	{
			$TotalRecordCount = $TotalRecordCount + 1;
    		$mailto 	=	$data['Email'];

    		$mail->Body    = $this->getMailBodyByCampaign($this->CampaignName,$data['MessageSent']);
			$this->messageOut($mail->Body);exit;
			$mail->CharSet = 'UTF-8';

    		if(strlen($mailto) > 10){
				if(preg_match('/\s/', $mailto)){
					$this->messageOut('mailwithSpaces: '.$mailto.'');

					$mailto = str_replace(' ', '', $mailto);
					if(!filter_var($mailto,FILTER_VALIDATE_EMAIL)){
						$InvalidRecordCount = $InvalidRecordCount + 1;
						$this->messageOut('Invalid Mail '.$mailto.'');
						continue;
					}

					$mail->ClearAllRecipients();
					
					$mail->addAddress($mailto, $data['MessageSent']);

					if($mail->send()){
						$SendCount = $SendCount +1;
						$this->messageOut('Mail Sent to '.$mailto.'');
					}
				}
			}
			else{
				$this->messageOut('mailto Mail '.$mailto.'');
			}
		}
		
		$this->messageOut('TotalRecordCount: '.$TotalRecordCount.'');
		$this->messageOut('InvalidRecordCount: '.$InvalidRecordCount.'');
		$this->messageOut('SendCount: '.$SendCount.'');
    }

    function getDataFromDLRFailedReport()
    {
		$SrcFile	= 	"DLRReport.csv";

	    $handle = fopen($SrcFile, "r");

		$counter	=	0;

	    while(($data = fgetcsv($handle, 1000, ",")) !== FALSE)
	    {	
			$counter += 1;

			if($counter == 1 || $counter < 300){
				continue;
			}

			$Number			=	$data[5];

			if(strlen($Number) == 12){
				$Number 	= 	substr($Number,2);
			}

			$NumberRecord	=	"SELECT * FROM PsoriatreatSMSRecords WHERE Number = '$Number' LIMIT 1";		

			$SingleRecord	=	$this->con_working->query($NumberRecord);

			$SingleRecord	=	mysqli_fetch_assoc($SingleRecord);

			$this->sendSMS($Number,$SingleRecord['MessageSent'],$SingleRecord['PatientName']);

			if($counter >= $this->MaxLoop){
				break;exit;
			}	
	    }
    }

    private function mobileNumberFilter($NumbersWithoutDash)
    {
    	$NumbersWithoutDash = str_replace("-","",$NumbersWithoutDash);

    	if(strlen($NumbersWithoutDash) == 11){
    		$NumbersWithoutDash = substr($NumbersWithoutDash,1);
    	}
    	if(strlen($NumbersWithoutDash) < 10 || strlen($NumbersWithoutDash) > 10){
    		$NumbersWithoutDash	= $this->stop;
    	}
    	if(strlen($NumbersWithoutDash) < 10 || strlen($NumbersWithoutDash) > 10 || $NumbersWithoutDash == "1234567890"){
    		$NumbersWithoutDash	= $this->stop;
    	}
    	$FirstLetter 	=	$NumbersWithoutDash[0];

    	$Check 			=	array("0","1","2","3","4","5");

    	if(in_array($FirstLetter,$Check)){
    		$NumbersWithoutDash	= $this->stop;
    	}
    	if(strpos($NumbersWithoutDash,".") !== FALSE){
    		$NumbersWithoutDash	= $this->stop;
    	}

    	return $NumbersWithoutDash;
    }

	private function getMessageByCampaign($campaign,$FirstName)
	{
		if($campaign == 1){
			return $this->getSmsMessageClinicShifting($FirstName);
		}elseif($campaign == 2){
			return $this->getSmsMessageAundhBranch($FirstName);
		}
	}
	
	private function getSmsMessageClinicShifting($FirstName)
	{
		$Message 	=	'Dear '.$FirstName.', From 16 July, our NEW address: 2nd Flr, Vijayshree Tarate Colony, Opp. Sonal Hall, Karve Road, Pune. Psoriatreat - Dr.R.S.Sonawane-7276061596';

		$Message	=	urlencode($Message);

		return $Message;
	}

	private function getSmsMessageAundhBranch($FirstName)
	{
		$Message	=	'Dear '.$FirstName.', New Aundh Branch: Sanjivani Polyclinic, 101, Stellar, Opp Reliance Mall, Aundh, Pune-7. 1st & 3rd Thursday at 11AM-7PM. Dr.Sonawane:7276061596';

		$Message	=	urlencode($Message);

		return $Message;
	}

	private function getMailBodyByCampaign($campaign,$FirstName)
	{
		if($campaign == 1){
			return $this->getMailBodyClinicShifting($FirstName);
		}elseif($campaign == 2){
			return $this->getMailBodyAundhBranch($FirstName);
		}
	}

    private function getMailBodyClinicShifting($FirstName)
    {
    	$body = 'Dear '.$FirstName.',<br><br>We are Happy to inform you that our clinic is shifting to new larger building from Tuesday July 16, 2019. Our phone numbers will remain same.<br><br>Our new office is air-conditioned and will provide bigger and more consulting rooms, large and comfortable waiting room.<br><br>The new address is:- Psoriatreat-Psoriasis Research and Homeopathic Clinics Pvt. Ltd., "Vijayshree", Second Floor, Tarate colony, opposite Sonal Hall, Karve road, Pune.<br><br>Phone:- 7276061596, 9404447919, 9420137455
		<br><br> Thank you<br> Dr. Rajendra Sonawane,
		<br>Psoriatreat - Psoriasis Research and Homeopathic Clinics Pvt. Ltd.
		<br>Email: dr.sonawane@psoriatreat.net, 
		<br>Phone: 7276061596, 9420137455.';

		$body .= '<br><br>प्रिय रूग्णांनो,<br><br>आपणास कळविण्यास अत्यंत आनंद होत आहे की मंगळवार दिनांक १६ जुलै पासुन आपल्या क्लिनीकचे नवीन प्रशस्त जागेत स्थलांतर होत आहे. संपर्कासाठी सर्व फोन नंबर तेच असतील.<br><br>नवीन क्लिनीक मध्ये मोठे व आरामदायक वेटींग रूम व अनेक कंसलटींग रूम्स आहेत. पुर्ण क्लिनीक वातानुकुलीत आहे.<br><br>नवीन पत्ता:- सोरियाट्रीट - सोरायसीस रिसर्च अँड होमिओपॅथीक क्लिनिकस प्रायव्हेट लिमिटेड, "विजयश्री", दुसरा मजला, तरटे कॉलनी, सोनल हॉल समोर, कर्वे रोड, पुणे.<br><br>फोन:- ७२७६०६१५९६, ९४०४४४७९१९, ९४२०१३७४५५
					<br><br> Thank you<br> Dr. Rajendra Sonawane,
					<br>Psoriatreat - Psoriasis Research and Homeopathic Clinics Pvt. Ltd.
					<br>Email: dr.sonawane@psoriatreat.net, 
					<br>Phone: 7276061596, 9420137455.';

		return $body;
	}

	private function getMailBodyAundhBranch($FirstName)
	{
		$body = 'Dear '.$FirstName.', <br><br>We are Happy to inform you that we are launching a NEW clinic in Aundh Pune on 1st August, 2019.<br><br>The new branch address is:- Psoriatreat-Psoriasis Research and Homeopathic Clinics Pvt. Ltd., Sanjivani Polyclinic, 101, Stellar, Opposite Reliance Mall, Aundh, Pune - 411007. <br><br>Dr. Sonawane will be in this new branch on 1st & 3rd Thursday every month from 11AM to 7PM.<br><br>Phone:- 7276061596, 9404447919, 9420137455<br><br>Thank you<br>Dr. Rajendra Sonawane,<br>Psoriatreat - Psoriasis Research and Homeopathic Clinics Pvt. Ltd.<br>Email: dr.sonawane@psoriatreat.net,<br>Phone: 7276061596, 9420137455.';

		return $body;
	}

	private function buildSmsApiURL($MoNumber,$Message)
	{
		$url =  'http://148.251.80.111:5665/api/SendSMS?api_id='.$this->api_id.'&api_password='.$this->api_password.'&sms_type='.$this->SmsType.'&encoding=T&sender_id='.$this->SenderID.'&phonenumber='.$MoNumber.'&textmessage='.$Message.'';

		return $url;
	}

	private function makeCallAndResponseSMS($url)
	{
		// $data 	=	file_get_contents($url);
		$ch 	=	curl_init();

		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);

		$data	=	curl_exec($ch);
		curl_close($ch);

		// $data 	=	array("message_id" => "12345","status" => "S", "remarks" => "Testing SMS Response");

		$data 	=	json_decode($data);

		return $data;
	}

	private function getResponseAndAddLogs($ResData,$Name,$FirstName,$Number,$Message)
	{
		if($ResData->status == 'S'){
				if($FirstName == "Patient"){
					$this->addSMSLog($Name,$Number,$ResData->status,$ResData->message_id,$Message,"Name set to Patient. Name has more than 10 OR less than 3 Characters");
				}else{
					$this->addSMSLog($Name,$Number,$ResData->status,$ResData->message_id,$Message,$ResData->remarks);
				}
				$this->messageOut("Message has been sent to ".$Number." successfully");
			}else{
				$this->addSMSLog($Name,$Number,$ResData->status,$ResData->message_id,$Message,$ResData->remarks);
				$this->messageOut($ResData);
			}
	}

	private function addSMSLog($ReceiverName,$MobileNumber,$SmsStatus,$MessageID,$Message,$comment)
	{
		$Message	=	addslashes($Message);
		
		$query	=	"INSERT INTO SmsLog (SenderID,SmsType,CampaignName,MobileNumber,ReceiverName,SentDateTime,SentSms,SmsStatus,MessageID,Comment)VALUES('$this->SenderID','$this->SmsType','$this->CampaignName','$MobileNumber','$ReceiverName','$this->SentDateTime','$Message','$SmsStatus','$MessageID','$comment')";

		if(!$this->con_working->query($query)){
			$this->messageOut(mysqli_error($this->con_working));
		}
	}

	private function messageOut($Message)
	{
		echo "<pre>";
		print_r($Message);
		echo "</pre>";
		ob_flush();
		flush();
	}
}
	
$run = new BhashSmsApi();
// $run->getDataFromFiles();
// $run->getDataFromDB();
// $run->sendSMS();
$run->sendEmails();
// $run->getDataFromDLRFailedReport();
?>