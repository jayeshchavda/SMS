import mysql.connector

def connect():
    connect     =   mysql.connector.connect(host="localhost",user="root",password="pass",database="DoSoft_DrRajendraSonawane_working")
    con     =   connect.cursor()
    return con
