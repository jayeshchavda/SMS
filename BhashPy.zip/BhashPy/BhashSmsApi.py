import datetime
import os
import mysql.connector
import urllib

class BhashSmsApi:
    def __init__(self):
        self.stop 		    =   "stop"
        self.api_id		    =   "API11082942526"
        self.api_password	=	"123456789"
        self.SenderID	    =	"PRHCPL"
        self.SmsType	    =	"T"
        self.CampaignName	=	"Pune Clinic Shifting"
        self.SentDateTime	=	datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.MaxLoop	    =	5000
    
    def firstMethod(self):
        connect     =   mysql.connector.connect(host="localhost",user="root",password="pass",database="DoSoft_DrRajendraSonawane_working")
        con            =   connect.cursor(dictionary=True)
        con.execute("SELECT * FROM PsoriatreatSMSRecords ORDER BY id DESC LIMIT 2")
        GetRecords  =   con.fetchall()
        for x in GetRecords:
            MoNumber    =   x['Number']
            FirstName   =   x['MessageSent']
            if(len(FirstName) > 10):
                FirstName   =   "Patient"
                Message     =   self.getMessageByCampaign(self.CampaignName,FirstName)
                print(Message)

    def getMessageByCampaign(self,campaign,FirstName):
        if(campaign == 1):
		    data    =   self.getSmsMessageClinicShifting(FirstName)
            return data
		elif(campaign == 2):
		    return      self.getSmsMessageAundhBranch()
	
    def getSmsMessageClinicShifting(self,FirstName)
	{
		Message 	=	'Dear '+FirstName+', From 16 July, our NEW address: 2nd Flr, Vijayshree Tarate Colony, Opp. Sonal Hall, Karve Road, Pune. Psoriatreat - Dr.R.S.Sonawane-7276061596';

		Message	=	urllib.parse.quote(Message)

		return Message;
	}

	def getSmsMessageAundhBranch(self,FirstName)
	{
		Message	=	'Dear '+FirstName+', New Aundh Branch: Sanjivani Polyclinic, 101, Stellar, Opp Reliance Mall, Aundh, Pune-7. 1st & 3rd Thursday at 11AM-7PM. Dr.Sonawane:7276061596';

		Message	=	urllib.parse.quote(Message)

		return Message;
	}

run = BhashSmsApi()
run.firstMethod()