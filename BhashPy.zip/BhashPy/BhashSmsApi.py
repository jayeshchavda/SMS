import datetime
import os
import mysql.connector
import sys
import urllib
import requests

class BhashSmsApi:
    def __init__(self):
        self.connect        =   mysql.connector.connect(host="localhost",user="root",password="pass",database="Doms_SmsEmail")
        self.con            =   self.connect.cursor(dictionary=True)
        self.stop 		    =   "stop"
        self.api_id		    =   "API11082942526"
        self.api_password	=	"123456789"
        self.SenderID	    =	"PRHCPL"
        self.SmsType	    =	"T"
        self.CampaignName	=	2
        self.SentDateTime	=	datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.MaxLoop	    =	5000
    
    def firstMethod(self):
        Query   =   "SELECT * FROM PsoriatreatSMSRecords ORDER BY id DESC LIMIT 2,1"
        self.con.execute(Query)
        GetRecords  =   self.con.fetchall()
        for x in GetRecords:
            try:
                MoNumber    =   x['Number']
                FirstName   =   x['MessageSent']
                if(len(FirstName) > 10):
                    FirstName   =   "Patient"
                if(len(str(MoNumber)) < 10):
                    continue
                Message     =   self.getMessageByCampaign(self.CampaignName,FirstName)
                url         =   self.buildSmsApiURL(MoNumber,Message)
                # ResData     =   self.makeCallAndResponseSMS(url)
                print(url)
            except:
                print("Failed to Execute")

    def getMessageByCampaign(self,campaign,FirstName):
        GetMessage  =   self.con.execute("SELECT SmsText FROM SmsCollections WHERE CampaignID = "+str(campaign)+" LIMIT 1")
        GetMessage  =  self.con.fetchone()
        GetMessage  =   GetMessage['SmsText']
        GetMessage  =   GetMessage % FirstName
        GetMessage  =   urllib.parse.quote(GetMessage)
        return GetMessage

    def buildSmsApiURL(self,Number,Message):
        url     =   'http://148.251.80.111:5665/api/SendSMS?api_id='+str(self.api_id)+'&api_password='+self.api_password+'&sms_type='+self.SmsType+'&encoding=T&sender_id='+self.SenderID+'&phonenumber='+str(Number)+'&textmessage='+str(Message)+''
        return url

    def makeCallAndResponseSMS(self,url):
        data = requests.get(url)
        return data

run = BhashSmsApi()
run.firstMethod()